package com.usa.ciclo4.reto2ciclo4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Reto2Ciclo4ApplicationTests {

    @Test
    void contextLoads() {
    }

}
